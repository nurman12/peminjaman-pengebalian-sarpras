<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="<?php echo e(asset('/front')); ?>/images/logo-polinema-sayap.png" height="35" alt="Porto Admin" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>
            <!-- start: search & user box -->
            <div class="header-right">

                <!-- <form class="search nav-form">
                    <div class="input-group input-search">
                        <input type="text" class="form-control" name="q" id="q" placeholder="Search...">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                        </span>
                    </div>
                </form>
                <span class="separator"></span> -->
                <?php

                use Illuminate\Support\Facades\Auth;

                if (Auth::user()->roles == 'KTU') {
                    $notif = App\Models\Validasi::where('validasi_ktu', 0)->where('validasi_koor', 0)->where('validasi_bmn', 0)->where('notif', 0)->get();
                } elseif (Auth::user()->roles == 'Koordinator') {
                    $notif = App\Models\Validasi::where('validasi_ktu', 1)->where('validasi_koor', 0)->where('validasi_bmn', 0)->where('notif', 0)->get();
                } elseif (Auth::user()->roles == 'BMN') {
                    $notif = App\Models\Validasi::where('validasi_ktu', 1)->where('validasi_koor', 1)->where('validasi_bmn', 0)->where('notif', 0)->get();
                }

                ?>
                <ul class="notifications">
                    <?php if(Auth::user()->roles == 'BMN'): ?>
                    <li>
                        <a href="#" class="notification-icon" id="ScanQRDraft" data-toggle="modal" data-target="#modalBootstrapScanDraf">
                            <i class="fa fa-qrcode"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="">
                        <a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown" aria-expanded="true">
                            <i class="fa fa-bell"></i>
                            <span class="badge"><?php echo e(count($notif)); ?></span>
                        </a>
                        <div class="dropdown-menu notification-menu">
                            <div class="notification-title">
                                Notifikasi
                            </div>

                            <div class="content">
                                <ul>
                                    <?php $__currentLoopData = $notif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="border-top: 1px solid #eee; padding-top: 5px;" class="hover-notif">
                                        <a href="/validasi/<?php echo e($data->id); ?>" class="clearfix">
                                            <figure class="image">
                                                <?php if($data->user->photo_profile): ?>
                                                <img src="<?php echo e(url('/storage/'. $data->user->photo_profile)); ?>" alt="<?php echo e($data->user->name); ?>" style="width: 4rem" class="img-circle">
                                                <?php else: ?>
                                                <img src="https://ui-avatars.com/api/?name=<?php echo e($data->user->name); ?>" style="width: 4rem" alt="" class="img-circle">
                                                <?php endif; ?>
                                            </figure>
                                            <span class="title"><?php echo e($data->user->name); ?></span>
                                            <span class="message"><?php echo e($data->keperluan); ?></span>
                                            <?php
                                            if (Auth::user()->roles == 'KTU') {
                                                $waktu_awal = new DateTime($data->created_at);
                                            } else {
                                                $waktu_awal = new DateTime($data->updated_at);
                                            }
                                            $waktu_skrg = new DateTime();

                                            $diff = date_diff($waktu_awal, $waktu_skrg);

                                            if ($diff->y == 0 && $diff->m == 0 && $diff->d == 0 && $diff->h == 0 && $diff->i == 0) {
                                                $selisih = $diff->s . ' detik yg lalu';
                                            } elseif ($diff->y == 0 && $diff->m == 0 && $diff->d == 0 && $diff->h == 0 && $diff->i != 0) {
                                                $selisih = $diff->i . ' menit yg lalu';
                                            } elseif ($diff->y == 0 && $diff->m == 0 && $diff->d == 0 && $diff->h != 0) {
                                                $selisih = $diff->h . ' jam yg lalu';
                                            } elseif ($diff->y == 0 && $diff->m == 0 && $diff->d != 0) {
                                                $selisih = $diff->d . ' hari yg lalu';
                                            } elseif ($diff->y == 0 && $diff->m != 0) {
                                                $selisih = $diff->m . ' bulan yg lalu';
                                            } elseif ($diff->y != 0) {
                                                $selisih = $diff->y . ' tahun yg lalu';
                                            }
                                            ?>
                                            <span class="message text-right"><?php echo e($selisih); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                                <hr>

                                <div class="text-right">
                                    <a href="#" class="view-more">View All</a>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <span class="separator"></span>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php if(Auth::user()->photo_profile): ?>
                            <img src="<?php echo e(url('/storage/'. Auth::user()->photo_profile)); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="img-rounded" />
                            <?php else: ?>
                            <img src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="img-circle" />
                            <?php endif; ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo e(Auth::user()->name); ?></span>
                            <span class="role"><?php echo e(Auth::user()->roles); ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="/profile"><i class="fa fa-user"></i> My Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="/edit"><i class="fa fa-gear"></i> Edit Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="/changePassword"><i class="fa fa-cogs"></i> Change Password</a>
                            </li>
                            <hr class="dotted short">
                            <li>
                                <a role="menuitem" tabindex="-1" href="<?php echo e(route('logout')); ?>" onclick=" event.preventDefault(); document.getElementById('formLogout').submit();">
                                    <i class="fa fa-power-off"></i> Logout
                                </a>
                                <form id="formLogout" action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header --><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/layouts/navbar.blade.php ENDPATH**/ ?>