
<?php $__env->startPush('title', 'Show Pwngguna'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Detail Pengguna</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Pengguna</span></li>
                <li><span style="margin-right: 20px;">Detail</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <div class="row">
        <div class="col-md-4 col-lg-3">
            <section class="panel">
                <div class="panel-body">
                    <div class="thumb-info mb-md">
                        <?php if($user->photo_profile): ?>
                        <img src="<?php echo e(url('/storage/'. $user->photo_profile)); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php else: ?>
                        <img src="https://ui-avatars.com/api/?name=<?php echo e($user->name); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php endif; ?>
                        <div class="thumb-info-title">
                            <span class="thumb-info-inner"><?php echo e($user->name); ?></span>
                            <span class="thumb-info-type"><?php echo e($user->roles); ?></span>
                        </div>
                    </div>

                    <h6 class="text-muted">Data Profile</h6>
                    <ul class="simple-todo-list">
                        <li class="<?php echo e($user->photo_profile ? 'completed' : 'text-warning'); ?>">Update Poto Profil</li>
                        <li class="<?php echo e($user->change_Password != 0 ? 'completed' : 'text-warning'); ?>">Ganti Password</li>
                    </ul>
                    <?php if($user->roles == 'Mahasiswa' || $user->roles == 'Dosen'): ?>
                    <hr class="dotted short">

                    <div class="social-icons-list">
                        <blockquote class="primary rounded b-thin mt-md" style="background-color: #f5f5f5;">
                            <div class="user-rating">
                                <h3><?php echo e($rate); ?></h3>
                                <div id="rate-rating">
                                    <div class="star">
                                        <?php if($rate == 0): ?><i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <?php elseif($rate <= 0.8 ): ?> <i class="fa fa-star-half-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <?php elseif($rate <=1.2): ?> <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <?php elseif($rate <=1.8): ?> <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <?php elseif($rate <=2.2): ?> <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <?php elseif($rate <=2.8): ?> <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star-half-o"></i>
                                                            <i class="fa fa-star-o"></i>
                                                            <i class="fa fa-star-o"></i>
                                                            <?php elseif($rate <=3.2): ?> <i class="fa fa-star"></i>
                                                                <i class="fa fa-star"></i>
                                                                <i class="fa fa-star"></i>
                                                                <i class="fa fa-star-o"></i>
                                                                <i class="fa fa-star-o"></i>
                                                                <?php elseif($rate <=3.8): ?> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star-half-o"></i>
                                                                    <i class="fa fa-star-o"></i>
                                                                    <?php elseif($rate <=4.2): ?> <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star-o"></i>
                                                                        <?php elseif($rate <=4.8): ?> <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star-half-o"></i>
                                                                            <?php elseif($rate <=5): ?> <i class="fa fa-star"></i>
                                                                                <i class="fa fa-star"></i>
                                                                                <i class="fa fa-star"></i>
                                                                                <i class="fa fa-stars"></i>
                                                                                <i class="fa fa-star-o"></i>
                                                                                <?php endif; ?>
                                    </div>
                                    <span class="no-user">
                                        <span><?php echo e($jumlah); ?></span>&nbsp;&nbsp;
                                        reviews
                                    </span>
                                </div>
                            </div>

                        </blockquote>
                    </div>
                    <?php endif; ?>
                </div>
            </section>

        </div>
        <div class="col-md-8 col-lg-9">
            <div class="tabs">
                <ul class="nav nav-tabs tabs-primary">
                    <li class="<?php echo e(request()->is('pengguna/*') ? 'active' : ''); ?>">
                        <a href="#overview" data-toggle="tab">Home</a>
                    </li>
                    <?php if($user->roles == 'Mahasiswa' || $user->roles == 'Dosen'): ?>
                    <li>
                        <a href="#other" data-toggle="tab">Lainnya</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="tab-content">
                    <div id="overview" class="tab-pane <?php echo e(request()->is('pengguna/*') ? 'active' : ''); ?>">
                        <h4 class="mb-md">About Me</h4>
                        <div class="row">
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>NIDN</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->nim_nidn); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Status</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->status_mhs ? $user->status_mhs : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Jenis Kelamin</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->jenis_kelamin ? $user->jenis_kelamin : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Alamat</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->alamat ? $user->alamat : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Rt / Rw</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->rt ? $user->rt : 'null'); ?> / <?php echo e($user->rw ? $user->rw : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Desa</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->desa ? $user->desa : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>Kota / Kabupaten</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8">
                                <h5><?php echo e($user->kota ? $user->kota : 'null'); ?></h5>
                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-4">
                                <h5>No. Telp</h5>
                            </div>
                            <div class="col-md-8 col-lg-8 col-sm-8 mb-xlg">
                                <h5><?php echo e($user->no_telp ? $user->no_telp : 'null'); ?></h5>
                            </div>
                        </div>
                    </div>
                    <div id="other" class="tab-pane">
                        <section class="panel">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Daftar Permohonan Pinjaman</h2>
                            </header>
                            <div class="panel-body">
                                <table class="table table-bordered table-striped mb-none" id="datatable-default-1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Keperluan</th>
                                            <th>Jumlah</th>
                                            <th>Tanggal</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><a href="<?php echo e(route('validasi.show', $data->id)); ?>" style="color: #7280e0;"><?php echo e($data->keperluan); ?></a></td>
                                            <td><?php echo e(count($data->draft)); ?></td>
                                            <td><?php echo e(date('d F', strtotime( $data->tanggal_start ))); ?> sd. <?php echo e(date('d F Y', strtotime( $data->tanggal_finish ))); ?></td>
                                            <td>
                                                <?php if( $data->status == 3 ): ?>
                                                <label class="badge badge-danger shadow">Kadaluarsa</label>
                                                <?php elseif( $data->validasi_ktu == 1 && $data->validasi_koor == 1 && $data->validasi_bmn == 1 && $data->status == 0 ): ?>
                                                <label class="badge badge-success shadow">Disetujui</label>
                                                <?php elseif( $data->validasi_ktu == 1 && $data->validasi_koor == 1 && $data->validasi_bmn == 0 ): ?>
                                                <label class="badge badge-light shadow">Seleksi BMN</label>
                                                <?php elseif( $data->validasi_ktu == 1 && $data->validasi_koor == 0 && $data->validasi_bmn == 0 ): ?>
                                                <label class="badge badge-light shadow">Seleksi Koordinator</label>
                                                <?php elseif( $data->validasi_ktu == 0 && $data->validasi_koor == 0 && $data->validasi_bmn == 0 ): ?>
                                                <label class="badge badge-light shadow">Seleksi TU</label>
                                                <?php elseif( $data->validasi_ktu == 1 && $data->validasi_koor == 1 && $data->validasi_bmn == 2 ): ?>
                                                <label class="badge badge-danger shadow">Tolak BMN</label>
                                                <?php elseif( $data->validasi_ktu == 1 && $data->validasi_koor == 2 && $data->validasi_bmn == 0 ): ?>
                                                <label class="badge badge-danger shadow">Tolak Koordionator</label>
                                                <?php elseif( $data->validasi_ktu == 2 && $data->validasi_koor == 0 && $data->validasi_bmn == 0 ): ?>
                                                <label class="badge badge-danger shadow">Tolak TU</label>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                        <section class="panel">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Daftar Pinjaman</h2>
                            </header>
                            <div class="panel-body">
                                <table class="table table-bordered table-striped mb-none" id="datatable-default-2">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Keperluan</th>
                                            <th>Jumlah</th>
                                            <th>Tanggal Ambil</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><a href="<?php echo e(route('peminjaman.show', $data->id)); ?>" style="color: #7280e0;"><?php echo e($data->validasi->keperluan); ?></a></td>
                                            <td><?php echo e(count($data->validasi->draft)); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime( $data->date_ambil ))); ?></td>
                                            <td>
                                                <?php if($data->status == 0): ?>
                                                <label class="badge badge-light shadow">Tanggungan</label>
                                                <?php elseif($data->status == 1): ?>
                                                <label class="badge badge-success shadow">Success</label>
                                                <?php elseif($data->status == 2): ?>
                                                <label class="badge badge-danger shadow">Kerusakan</label>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                        <section class="panel">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Daftar Pengembalian</h2>
                            </header>
                            <div class="panel-body">
                                <table class="table table-bordered table-striped mb-none" id="datatable-default-3">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Keperluan</th>
                                            <th>Tanggal Ambil</th>
                                            <th>Tanggal Kembali</th>
                                            <th>Penilaian</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pengembalian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><a href="<?php echo e(route('pengembalian.show', $data->id)); ?>" style="color: #7280e0;"><?php echo e($data->validasi->keperluan); ?></a></td>
                                            <td><?php echo e(date('d F Y', strtotime( $data->date_ambil ))); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime( $data->date_kembali ))); ?></td>
                                            <td id="rate-rating">
                                                <?php if($data->rating): ?>
                                                <?php if($data->rating->penilaian == 1): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <?php elseif($data->rating->penilaian == 2): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <?php elseif($data->rating->penilaian == 3): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <?php elseif($data->rating->penilaian == 4): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <?php elseif($data->rating->penilaian == 5): ?>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <?php endif; ?>
                                                <?php else: ?>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<script>
    function previewImage(input) {
        var file = $("input[type=file]").get(0).files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function() {
                $('#preview_pengguna').attr("src", reader.result);
            }
            reader.readAsDataURL(file);
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/pengguna/show.blade.php ENDPATH**/ ?>