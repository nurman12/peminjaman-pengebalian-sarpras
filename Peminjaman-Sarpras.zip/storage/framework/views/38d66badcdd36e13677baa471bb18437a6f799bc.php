
<?php $__env->startPush('title', 'Create | Sarpras Keluar'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Create Sarpras Keluar</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Sarpras</span></li>
                <li><span>Keluar</span></li>
                <li><span style="margin-right: 20px;">Create</span></li>
            </ol>
        </div>
    </header>
    <!-- Start page -->
    <div class="row">
        <div class="col-xs-6">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <a href="#" class="fa fa-times"></a>
                    </div>
                    <h2 class="panel-title">Select Replacement</h2>
                </header>
                <div class="panel-body">
                    <form class="form-horizontal form-bordered" action="<?php echo e(route('sarpras_keluar.store')); ?>" method="POST" id="formcreate">
                        <?php echo csrf_field(); ?>
                        <div class="form-group <?php $__errorArgs = ['sarpras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label">Sarpras<span class="required">*</span></label>
                            <div class="col-md-8">
                                <select data-plugin-selectTwo class="form-control" name="sarpras" id="sarpras">
                                    <option selected disabled></option>
                                    <optgroup label="Barang">
                                        <?php $__currentLoopData = $sarpras_brg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" data-stok="<?php echo e($data->jumlah); ?>" <?php echo e(old('sarpras') == $data->id ? 'selected' : null); ?>><?php echo e($data->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                    <optgroup label="Ruangan">
                                        <?php $__currentLoopData = $sarpras_rgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>" data-stok="<?php echo e($data->jumlah); ?>" <?php echo e(old('sarpras') == $data->id ? 'selected' : null); ?>><?php echo e($data->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                </select>
                                <?php $__errorArgs = ['sarpras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group" id="details">
                            <label class="col-md-3 control-label" for="total_stok">Stok</label>
                            <div class="col-md-8">
                                <h5 id="stok"></h5>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="jumlah">Jumlah Keluar<span class="required">*</span></label>
                            <div class="col-md-8">
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                <input type="number" class="form-control" value="<?php echo e(old('jumlah')); ?>" id="jumlah" name="jumlah">
                                <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group" id="detailss">
                            <label class="col-md-3 control-label" for="total_stok">Total Stok</label>
                            <div class="col-md-8">
                                <h5 id="total_stok"></h5>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="tanggal">Tanggal Masuk<span class="required">*</span></label>
                            <div class="col-md-8">
                                <input type="date" class="form-control" value="<?php echo e(old('tanggal')); ?>" id="tanggal" name="tanggal">
                                <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="keterangan">Keterangan<span class="required">*</span></label>
                            <div class="col-md-8">
                                <textarea name="keterangan" id="keterangan" rows="5" class="form-control" placeholder="Describe keterangan"><?php echo e(old('keterangan')); ?></textarea>
                                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-9 col-md-offset-3">
                            <button onclick="document.getElementById('formcreate').submit()" class="btn btn-primary">Submit</button>
                            <button onclick="document.getElementById('formcreate').reset()" class="btn btn-default">Reset</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-colorpicker/css/bootstrap-colorpicker.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-timepicker/css/bootstrap-timepicker.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/dropzone/css/basic.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/dropzone/css/dropzone.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-markdown/css/bootstrap-markdown.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/summernote/summernote.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/summernote/summernote-bs3.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/codemirror/lib/codemirror.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/codemirror/theme/monokai.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-validation/jquery.validate.js"></script>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-maskedinput/jquery.maskedinput.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/fuelux/js/spinner.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/dropzone/dropzone.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-markdown/js/markdown.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-markdown/js/to-markdown.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-markdown/js/bootstrap-markdown.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/lib/codemirror.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/addon/selection/active-line.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/addon/edit/matchbrackets.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/mode/javascript/javascript.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/mode/htmlmixed/htmlmixed.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/codemirror/mode/css/css.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/summernote/summernote.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-maxlength/bootstrap-maxlength.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/ios7-switch/ios7-switch.js"></script>
<script type="text/javascript">
    $('#details').hide();
    $('#detailss').hide();

    $(document).ready(function() {
        $("#sarpras").change(function() {
            var stok = $(this).find(':selected').data("stok");

            $('#details').show();
            $('#detailss').hide();
            $('#stok').text(stok);
            $('#jumlah').val('');
            $('#total_stok').text();
        })
    });
    $('#jumlah').keyup(function() {
        var a = parseInt($('#stok').text());
        var b = parseInt($('#jumlah').val());
        var c = a - b;
        $('#detailss').show();
        $('#total_stok').text(c);
    });
    $('#jumlah').click(function() {
        var a = parseInt($('#stok').val());
        var b = parseInt($('#jumlah').val());
        var c = a - b;
        $('#detailss').show();
        $('#total_stok').text(c);
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/forms/examples.advanced.form.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/sarpras_keluar/create.blade.php ENDPATH**/ ?>