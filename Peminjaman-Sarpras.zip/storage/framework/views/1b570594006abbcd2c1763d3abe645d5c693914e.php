
<?php $__env->startPush('title', 'Validasi | Detail'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Detail Validasi</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>validasi</span></li>
                <li><span style="margin-right: 20px;">Detail</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <div class="row">
        <div class="col-md-4 col-lg-3">
            <section class="panel">
                <div class="panel-body">
                    <div class="thumb-info mb-md">
                        <?php if($validasi->user->photo_profile): ?>
                        <img src="<?php echo e(url('/storage/'. $validasi->user->photo_profile)); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php else: ?>
                        <img src="https://ui-avatars.com/api/?name=<?php echo e($validasi->user->name); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php endif; ?>
                        <div class="thumb-info-title">
                            <span class="thumb-info-inner"><?php echo e($validasi->user->name); ?></span>
                            <span class="thumb-info-type"><?php echo e($validasi->user->roles); ?></span>
                        </div>
                    </div>

                    <h6 class="text-muted">Data Profile</h6>
                    <div class="content">
                        <ul class="simple-user-list">
                            <li>
                                <span class="title">NIM/NIDN</span>
                                <span class="message truncate"><?php echo e($validasi->user->nim_nidn); ?></span>
                            </li>
                            <li>
                                <span class="title">Email</span>
                                <span class="message truncate"><?php echo e($validasi->user->email); ?></span>
                            </li>
                            <li>
                                <span class="title">No Telp</span>
                                <span class="message truncate"><?php echo e($validasi->user->no_telp); ?></span>
                            </li>
                        </ul>
                    </div>
                    <?php if($validasi->user->roles == 'Mahasiswa' || $validasi->user->roles == 'Dosen'): ?>
                    <hr class="dotted short">

                    <div class="social-icons-list">
                        <blockquote class="primary rounded b-thin mt-md" style="background-color: #f5f5f5;">
                            <div class="user-rating">
                                <h3><?php echo e($rate); ?></h3>
                                <div id="rate-rating">
                                    <div class="star">
                                        <?php if($rate == 0): ?><i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                        <?php elseif($rate <= 0.8 ): ?> <i class="fa fa-star-half-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <?php elseif($rate <=1.2): ?> <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                                <?php elseif($rate <=1.8): ?> <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <i class="fa fa-star-o"></i>
                                                    <?php elseif($rate <=2.2): ?> <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <i class="fa fa-star-o"></i>
                                                        <?php elseif($rate <=2.8): ?> <i class="fa fa-star"></i>
                                                            <i class="fa fa-star"></i>
                                                            <i class="fa fa-star-half-o"></i>
                                                            <i class="fa fa-star-o"></i>
                                                            <i class="fa fa-star-o"></i>
                                                            <?php elseif($rate <=3.2): ?> <i class="fa fa-star"></i>
                                                                <i class="fa fa-star"></i>
                                                                <i class="fa fa-star"></i>
                                                                <i class="fa fa-star-o"></i>
                                                                <i class="fa fa-star-o"></i>
                                                                <?php elseif($rate <=3.8): ?> <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star-half-o"></i>
                                                                    <i class="fa fa-star-o"></i>
                                                                    <?php elseif($rate <=4.2): ?> <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star"></i>
                                                                        <i class="fa fa-star-o"></i>
                                                                        <?php elseif($rate <=4.8): ?> <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star-half-o"></i>
                                                                            <?php elseif($rate <=5): ?> <i class="fa fa-star"></i>
                                                                                <i class="fa fa-star"></i>
                                                                                <i class="fa fa-star"></i>
                                                                                <i class="fa fa-stars"></i>
                                                                                <i class="fa fa-star-o"></i>
                                                                                <?php endif; ?>
                                    </div>
                                    <span class="no-user">
                                        <span><?php echo e($jumlah); ?></span>&nbsp;&nbsp;
                                        reviews
                                    </span>
                                </div>
                            </div>

                        </blockquote>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
        <div class="col-md-8 col-lg-9">
            <section class="panel">
                <div class="panel-body">
                    <div class="row mb-xl">
                        <div class="col-md-8 col-sm-12">
                            <div class="flex-w flex-t">
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Jumlah
                                    </span>
                                </div>
                                <div class="size-209">
                                    <span class="stext-115 cl2">
                                        <?php echo e(count($validasi->draft)); ?>

                                    </span>
                                </div>
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Proposal
                                    </span>
                                </div>
                                <div class="size-209">
                                    <span class="stext-115 cl2">
                                        <a href="/storage/<?php echo e($validasi->proposal); ?>" target="_blank" rel="noopener noreferrer">
                                            <span class="mb-xs mt-xs btn btn-success btn-xs c-default" style="cursor: pointer;"> <i class="fa fa-download"></i> Download</span>
                                        </a>
                                    </span>
                                </div>
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Keperluan
                                    </span>
                                </div>
                                <div class="size-209">
                                    <span class="stext-115 cl2">
                                        <?php echo e($validasi->keperluan); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <div class="flex-w flex-t">
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Mulai
                                    </span>
                                </div>
                                <div class="size-209">
                                    <span class="stext-115 cl2">
                                        <?php echo e(date('d F Y H:i', strtotime( $validasi->tanggal_start ))); ?>

                                    </span>
                                </div>
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Sampai
                                    </span>
                                </div>
                                <div class="size-209">
                                    <span class="stext-115 cl2">
                                        <?php echo e(date('d F Y H:i', strtotime( $validasi->tanggal_finish ))); ?>

                                    </span>
                                </div>
                                <div class="size-208">
                                    <span class="stext-115 cl2">
                                        Status
                                    </span>
                                </div>
                                <div class="size-209">
                                    <?php if( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 1 && $validasi->status == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-success btn-xs c-default">Disetujui <i class="fa fa-check-circle"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-primary btn-xs c-default">Seleksi BMN <i class="fa fa-spinner"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 0 && $validasi->validasi_bmn == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-primary btn-xs c-default">Seleksi Koordinator <i class="fa fa-spinner"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 0 && $validasi->validasi_koor == 0 && $validasi->validasi_bmn == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-primary btn-xs c-default">Seleksi TU <i class="fa fa-spinner"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 2 ): ?>
                                    <span class="mb-xs mt-xs btn btn-danger btn-xs c-default">Tolak BMN <i class="fa fa-times-circle"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 2 && $validasi->validasi_bmn == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-danger btn-xs c-default">Tolak Koordinator <i class="fa fa-times-circle"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 2 && $validasi->validasi_koor == 0 && $validasi->validasi_bmn == 0 ): ?>
                                    <span class="mb-xs mt-xs btn btn-danger btn-xs c-default">Tolak TU <i class="fa fa-times-circle"></i></span>
                                    <?php elseif( $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 1 && $validasi->status == 1 ): ?>
                                    <span class="mb-xs mt-xs btn btn-info btn-xs c-default">Diambil <i class="fa fa-fax"></i></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-xl">
                        <?php if(Auth::user()->roles == 'KTU' && $validasi->validasi_ktu == 0 && $validasi->validasi_koor == 0 || Auth::user()->roles == 'KTU' && $validasi->validasi_ktu == 1 && $validasi->validasi_koor == 0 || Auth::user()->roles == 'KTU' && $validasi->validasi_ktu == 2 && $validasi->validasi_koor == 0): ?>
                        <?php if($validasi->validasi_ktu == 0): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_ktu" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_ktu" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <?php elseif($validasi->validasi_ktu == 2): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_ktu" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <?php elseif($validasi->validasi_ktu == 1): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_ktu" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <?php endif; ?>
                        <?php elseif(Auth::user()->roles == 'Koordinator' && $validasi->validasi_koor == 0 && $validasi->validasi_bmn == 0 || Auth::user()->roles == 'Koordinator' && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 0 || Auth::user()->roles == 'Koordinator' && $validasi->validasi_koor == 2 && $validasi->validasi_bmn == 0): ?>
                        <?php if($validasi->validasi_koor == 0): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_koor" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_koor" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <?php elseif($validasi->validasi_koor == 2): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_koor" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <?php elseif($validasi->validasi_koor == 1): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_koor" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <?php endif; ?>
                        <?php elseif(Auth::user()->roles == 'BMN' && $validasi->validasi_bmn == 0 && $validasi->status == 0 || Auth::user()->roles == 'BMN' && $validasi->validasi_bmn == 1 && $validasi->status == 0 || Auth::user()->roles == 'BMN' && $validasi->validasi_bmn == 3 && $validasi->status == 0): ?>
                        <?php if($validasi->validasi_bmn == 0): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_bmn" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sebelum_bmn" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <?php elseif($validasi->validasi_bmn == 2): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_bmn" value="1">
                            <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button>
                        </form>
                        <?php elseif($validasi->validasi_bmn == 1): ?>
                        <form action="/validasi/<?php echo e($validasi->id); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="sudah_bmn" value="2">
                            <button type="submit" class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i>Tolak</button>
                        </form>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php if($validasi->validasi_ktu == 1 && $validasi->validasi_koor == 1 && $validasi->validasi_bmn == 1 && $validasi->status == 0): ?>
                    <a id="ambil" data-validasi_id="<?php echo e($validasi->id); ?>" data-user_id="<?php echo e($validasi->user_id); ?>" class="mb-xl btn btn-success btn-xs" data-toggle="tooltip" data-placement="top" title="Ambil"> <i class="fa fa-truck"></i> Ambil</a>
                    <?php endif; ?>
                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama</th>
                                <th>Jumlah</th>
                                <th class="center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $validasi->draft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($data->sarpras->nama); ?></td>
                                <td><?php echo e($data->qty == 0 ? $data->sarpras_keluar->jumlah : $data->qty); ?></td>
                                <td class="center">
                                    <a href="#Photo" id="show" data-nama_item="<?php echo e($data->sarpras->nama); ?>" data-img="<?php echo e($data->sarpras->photo); ?>" data-desc="<?php echo e($data->sarpras->deskripsi); ?>" class="btn btn-primary btn-sm modal-with-zoom-anim" data-toggle="tooltip" data-placement="top" title="Foto">
                                        <i class="fa fa-picture-o"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('modals'); ?>
<div id="Photo" class="zoom-anim-dialog modal-block modal-block-primary mfp-hide">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title"></h2>
        </header>
        <div class="panel-body">
            <div class="modal-wrapper">
                <div class="row">
                    <div class="col-md-4">
                        <img id="img" class="img-responsive" src="">
                    </div>
                    <div class="col-md-8">
                        <p id="deskripsi"></p>
                    </div>
                </div>
            </div>
        </div>
        <footer class="panel-footer">
            <div class="row">
                <div class="col-md-12 text-right">
                    <button class="btn btn-default modal-dismiss">Cancel</button>
                </div>
            </div>
        </footer>
    </section>
</div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).on('click', '#show', function() {
        var nama = $(this).data('nama_item');
        var img = $(this).data('img');
        var desc = $(this).data('desc');

        $('.panel-title').text(nama);
        $('#img').attr("src", '/storage/' + img);
        $('p#deskripsi').text(desc);
    });
    $(document).on('click', '#ambil', function() {
        var validasi_id = $(this).data('validasi_id');
        var user_id = $(this).data('user_id');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        swal.fire({
            title: 'Apa kamu yakin?',
            text: "Peminjam mengambil sarpras peminjaman!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, yakin!',
            cancelButtonText: 'Tidak'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    method: "POST",
                    url: "<?php echo e(route('peminjaman.store')); ?>",
                    data: {
                        'validasi_id': validasi_id,
                        'user_id': user_id,
                    },
                    success: function(response) {
                        if (response.error_message) {
                            swal.fire({
                                icon: 'error',
                                title: 'Oops..!',
                                text: response.error_message
                            });
                        } else if (response.success_message) {
                            swal.fire({
                                icon: 'success',
                                title: 'Berhasil',
                                text: response.success_message
                            }).then((result) => {
                                location.reload();
                            })
                        }
                    },
                    error: function(xhr) {
                        swal.fire({
                            icon: 'error',
                            title: 'Oops..!',
                            text: 'Someting went wrong!'
                        });
                    }
                });
            }
        })
    });
</script>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<script src="<?php echo e(asset('/back')); ?>/javascripts/ui-elements/examples.modals.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/back/validasi/show.blade.php ENDPATH**/ ?>