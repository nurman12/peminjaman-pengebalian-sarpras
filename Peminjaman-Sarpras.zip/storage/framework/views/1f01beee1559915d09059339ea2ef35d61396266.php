<?php echo e($slot); ?>

<?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/table.blade.php ENDPATH**/ ?>