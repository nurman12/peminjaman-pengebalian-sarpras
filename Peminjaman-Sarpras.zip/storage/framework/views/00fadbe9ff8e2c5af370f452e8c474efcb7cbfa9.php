<div class="inner-wrapper">
    <!-- start: sidebar -->
    <aside id="sidebar-left" class="sidebar-left">

        <div class="sidebar-header">
            <div class="sidebar-title" style="color: white;">
                Navigation
            </div>
            <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
                <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
            </div>
        </div>

        <div class="nano">
            <div class="nano-content">
                <nav id="menu" class="nav-main" role="navigation">
                    <ul class="nav nav-main">
                        <li class="<?php echo e(request()->is('dashboard') ? 'nav-active' : ''); ?>">
                            <a href="/dashboard">
                                <i class="fa fa-home" aria-hidden="true"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <?php if(Auth::user()->roles == 'BMN'): ?>
                        <li class="<?php echo e(request()->is('pengguna*') ? 'nav-active' : ''); ?>">
                            <a href="<?php echo e(route('pengguna.index')); ?>">
                                <span class="pull-right label label-primary"><?php echo e(count(App\Models\User::all())); ?></span>
                                <i class="fa fa-users" aria-hidden="true"></i>
                                <span>Pengguna</span>
                            </a>
                        </li>
                        <?php if(request()->is('sarpras*') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php else: ?>
                        <li class="nav-parent">
                            <?php endif; ?>
                            <a>
                                <i class="fa fa-copy" aria-hidden="true"></i>
                                <span>Sarpras</span>
                            </a>
                            <ul class="nav nav-children">
                                <?php if(request()->is('sarpras')): ?>
                                <li class="<?php echo e(request()->is('sarpras') ? 'nav-active' : ''); ?>">
                                    <?php elseif(request()->is('sarpras/*')): ?>
                                <li class="<?php echo e(request()->is('sarpras/*') ? 'nav-active' : ''); ?>">
                                    <?php else: ?>
                                <li>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('sarpras.index')); ?>">
                                        Master Data
                                    </a>
                                </li>
                                <?php if(request()->is('sarpras_masuk')): ?>
                                <li class="<?php echo e(request()->is('sarpras_masuk') ? 'nav-active' : ''); ?>">
                                    <?php elseif(request()->is('sarpras_masuk/*')): ?>
                                <li class="<?php echo e(request()->is('sarpras_masuk/*') ? 'nav-active' : ''); ?>">
                                    <?php else: ?>
                                <li>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('sarpras_masuk.index')); ?>">
                                        Sarpras Masuk
                                    </a>
                                </li>
                                <?php if(request()->is('sarpras_keluar')): ?>
                                <li class="<?php echo e(request()->is('sarpras_keluar') ? 'nav-active' : ''); ?>">
                                    <?php elseif(request()->is('sarpras_keluar/*')): ?>
                                <li class="<?php echo e(request()->is('sarpras_keluar/*') ? 'nav-active' : ''); ?>">
                                    <?php else: ?>
                                <li>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('sarpras_keluar.index')); ?>">
                                        Sarpras Keluar
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php if(request()->is('*validasi') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php elseif(request()->is('validasi*')): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php else: ?>
                        <li class="nav-parent">
                            <?php endif; ?>
                            <a>
                                <i class="fa fa-check-square-o" aria-hidden="true"></i>
                                <span>Validasi</span>
                            </a>
                            <ul class="nav nav-children">
                                <li class="<?php echo e(request()->is('belum_validasi') ? 'nav-active' : ''); ?>">
                                    <a href="/belum_validasi">
                                        Belum Validasi
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('sudah_validasi') ? 'nav-active' : ''); ?>">
                                    <a href="/sudah_validasi">
                                        Sudah Validasi
                                    </a>
                                </li>
                                <?php if(request()->is('validasi')): ?>
                                <li class="<?php echo e(request()->is('validasi') ? 'nav-active' : ''); ?>">
                                    <?php elseif(request()->is('validasi*')): ?>
                                <li class="<?php echo e(request()->is('validasi*') ? 'nav-active' : ''); ?>">
                                    <?php else: ?>
                                <li>
                                    <?php endif; ?>
                                    <a href="/validasi">
                                        Semua Validasi
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('expired_validasi*') ? 'nav-active' : ''); ?>">
                                    <a href="/expired_validasi">
                                        Kedaluwarsa
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::user()->roles == 'KTU' || Auth::user()->roles == 'Koordinator' ): ?>
                        <?php if(request()->is('*validasi') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php elseif(request()->is('validasi*')): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php else: ?>
                        <li class="nav-parent">
                            <?php endif; ?>
                            <a>
                                <i class="fa fa-check-square-o" aria-hidden="true"></i>
                                <span>Validasi</span>
                            </a>
                            <ul class="nav nav-children">
                                <li class="<?php echo e(request()->is('belum_validasi') ? 'nav-active' : ''); ?>">
                                    <a href="/belum_validasi">
                                        Belum Validasi
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('sudah_validasi') ? 'nav-active' : ''); ?>">
                                    <a href="/sudah_validasi">
                                        Sudah Validasi
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                        <?php if(request()->is('ketersediaan') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php elseif(request()->is('kerusakan')): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php else: ?>
                        <li class="nav-parent">
                            <?php endif; ?>
                            <a>
                                <i class="fa fa-list-alt" aria-hidden="true"></i>
                                <span>Laporan</span>
                            </a>
                            <ul class="nav nav-children">
                                <li class="<?php echo e(request()->is('ketersediaan') ? 'nav-active' : ''); ?>">
                                    <a href="/ketersediaan">
                                        Ketersediaan
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('kerusakan') ? 'nav-active' : ''); ?>">
                                    <a href="/kerusakan">
                                        Kerusakan
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php if(Auth::user()->roles == 'BMN'): ?>
                        <hr class="sparator" separator>
                        <div class="sidebar-widget widget-tasks">
                            <div class="widget-header">
                                <h6 style="color: white;">MASTER DATA</h6>
                                <div class="widget-toggle" style="color: white;">+</div>
                            </div>
                            <div class="widget-content">
                                <ul class="list-unstyled m-none">
                                    <li class="nav-active">
                                        <a href="<?php echo e(route('peminjaman.index')); ?>">Peminjaman</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('pengembalian.index')); ?>">Pengembalian</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <hr class="sparator" separator>
                        <?php if(request()->is('perangkat') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php elseif(request()->is('schedule') ): ?>
                        <li class="nav-parent nav-expanded nav-active">
                            <?php else: ?>
                        <li class="nav-parent">
                            <?php endif; ?>
                            <a>
                                <i class="fa fa-send" aria-hidden="true"></i>
                                <span>WhatsApp</span>
                            </a>
                            <ul class="nav nav-children">
                                <li class="<?php echo e(request()->is('perangkat') ? 'nav-active' : ''); ?>">
                                    <a href="/perangkat">
                                        Perangkat
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('message') ? 'nav-active' : ''); ?>">
                                    <a href="/message">
                                        Message
                                    </a>
                                </li>
                                <li class="<?php echo e(request()->is('schedule') ? 'nav-active' : ''); ?>">
                                    <a href="/schedule">
                                        Schedule
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>

        </div>

    </aside>
    <!-- end: sidebar --><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/back/layouts/sidebar.blade.php ENDPATH**/ ?>