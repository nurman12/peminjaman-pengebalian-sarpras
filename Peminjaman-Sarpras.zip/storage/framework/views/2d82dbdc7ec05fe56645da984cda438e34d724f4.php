
<?php $__env->startPush('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Edit Pengguna</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Pengguna</span></li>
                <li><span style="margin-right: 20px;">Edit</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <div class="row">
        <div class="col-md-4 col-lg-3">
            <section class="panel">
                <div class="panel-body">
                    <div class="thumb-info mb-md">
                        <?php if($user->photo_profile): ?>
                        <img src="<?php echo e(url('/storage/photo/'. $user->photo_profile)); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php else: ?>
                        <img src="https://ui-avatars.com/api/?name=<?php echo e($user->name); ?>" id="preview_pengguna" class="rounded img-responsive" style="width: 35vh;">
                        <?php endif; ?>
                        <div class="thumb-info-title">
                            <span class="thumb-info-inner"><?php echo e($user->name); ?></span>
                            <span class="thumb-info-type"><?php echo e($user->roles); ?></span>
                        </div>
                    </div>

                    <h6 class="text-muted">Data Profile</h6>
                    <ul class="simple-todo-list">
                        <li class="<?php echo e($user->photo_profile ? 'completed' : 'text-warning'); ?>">Update Poto Profil</li>
                        <li class="<?php echo e($user->change_Password != 0 ? 'completed' : 'text-warning'); ?>">Ganti Password</li>
                    </ul>
                    <hr class="dotted short">

                    <div class="social-icons-list">
                        <a rel="tooltip" data-placement="bottom" target="_blank" href="http://www.facebook.com" data-original-title="Facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                        <a rel="tooltip" data-placement="bottom" href="http://www.twitter.com" data-original-title="Twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                        <a rel="tooltip" data-placement="bottom" href="http://www.linkedin.com" data-original-title="Linkedin"><i class="fa fa-linkedin"></i><span>Linkedin</span></a>
                    </div>

                </div>
            </section>

        </div>
        <div class="col-md-8 col-lg-9">
            <div class="tabs">
                <ul class="nav nav-tabs tabs-primary">
                    <li class="<?php echo e(request()->is('pengguna/*/edit') ? 'active' : ''); ?>">
                        <a href="#edit" data-toggle="tab">Edit Profile</a>
                    </li>
                    <li>
                        <a href="#changePassword" data-toggle="tab">Ubah Password</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="edit" class="tab-pane <?php echo e(request()->is('pengguna/*/edit') ? 'active' : ''); ?>">

                        <form class="form-horizontal" method="post" action="<?php echo e(route('pengguna.update', $user->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <h4 class="mb-xlg">Personal Information</h4>
                            <fieldset>
                                <div class="form-group <?php $__errorArgs = ['photo_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-3 control-label" for="photo_profile">Poto Profil</label>
                                    <div class="col-md-8">
                                        <input type="file" name="photo_profile" class="form-control" id="photo_profile" onchange="previewImage(this)">
                                        <input type="hidden" name="old_photo" value="<?php echo e($user->photo_profile); ?>">
                                        <?php $__errorArgs = ['photo_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-3 control-label" for="name">Nama</label>
                                    <div class="col-md-8">
                                        <input type="text" name="nama" class="form-control" id="name" value="<?php echo e($user->name); ?>">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-3 control-label" for="email">E-Mail</label>
                                    <div class="col-md-8">
                                        <input type="email" name="email" class="form-control" id="email" value="<?php echo e($user->email); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group <?php $__errorArgs = ['nim_nidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-3 control-label" for="nidn">NIM/NIDN/NIP</label>
                                    <div class="col-md-8">
                                        <input type="number" name="nim_nidn" class="form-control" id="nidn" value="<?php echo e($user->nim_nidn); ?>">
                                        <?php $__errorArgs = ['nim_nidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="lv">Level</label>
                                    <div class="col-md-8">
                                        <select name="roles" id="lv" class="form-control mb-md">
                                            <option value="BMN" <?php echo e($user->roles == 'BMN' ? 'selected' : null); ?>>BMN</option>
                                            <option value="Dosen" <?php echo e($user->roles == 'Dosen' ? 'selected' : null); ?>>Dosen</option>
                                            <option value="Koordinator" <?php echo e($user->roles == 'Koordinator' ? 'selected' : null); ?>>Koordinator</option>
                                            <option value="KTU" <?php echo e($user->roles == 'KTU' ? 'selected' : null); ?>>KTU</option>
                                            <option value="Mahasiswa" <?php echo e($user->roles == 'Mahasiswa' ? 'selected' : null); ?>>Mahasiswa</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="jk">Status</label>
                                    <div class="col-md-8">
                                        <select name="status_mhs" id="jk" class="form-control mb-md">
                                            <option value="Aktif" <?php echo e($user->status_mhs == 'Aktif' ? 'selected' : null); ?>>Aktif</option>
                                            <option value="Non Aktif" <?php echo e($user->status_mhs == 'Non Aktif' ? 'selected' : null); ?>>Non Aktif</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="jk">Jenis Kelamin</label>
                                    <div class="col-md-8">
                                        <select name="jenis_kelamin" id="jk" class="form-control mb-md">
                                            <option value="Laki-laki" <?php echo e($user->jenis_kelamin == 'Laki-laki' ? 'selected' : null); ?>>Laki-laki</option>
                                            <option value="Perempuan" <?php echo e($user->jenis_kelamin == 'Perempuan' ? 'selected' : null); ?>>Perempuan</option>
                                            <option value="Not Found" <?php echo e($user->jenis_kelamin == 'Not Found' ? 'selected' : null); ?>>Not Found</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="alamat">Alamat</label>
                                    <div class="col-md-8">
                                        <input type="text" name="alamat" class="form-control" id="alamat" value="<?php echo e($user->alamat); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="rt">Rt</label>
                                    <div class="col-md-8">
                                        <input type="number" name="rt" class="form-control" id="rt" value="<?php echo e($user->rt); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="rw">Rw</label>
                                    <div class="col-md-8">
                                        <input type="number" name="rw" class="form-control" id="rw" value="<?php echo e($user->rw); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="desa">Desa</label>
                                    <div class="col-md-8">
                                        <input type="text" name="desa" class="form-control" id="desa" value="<?php echo e($user->desa); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="kota">Kota / Kabupaten</label>
                                    <div class="col-md-8">
                                        <input type="text" name="kota" class="form-control" id="kota" value="<?php echo e($user->kota); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label" for="no_telp">No. Telpon</label>
                                    <div class="col-md-8">
                                        <input type="text" name="no_telp" class="form-control" id="no_telp" value="<?php echo e($user->no_telp); ?>">
                                    </div>
                                </div>
                            </fieldset>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-md-9 col-md-offset-3">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="reset" class="btn btn-default">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div id="changePassword" class="tab-pane  <?php echo e(request()->is('/pengguna/*/edit') ? 'active' : ''); ?>">
                        <form class="form-horizontal" method="post" action="/pengguna/<?php echo e($user->id); ?>/edit">
                            <?php echo csrf_field(); ?>
                            <h4 class="mb-xlg">Ubah Password</h4>
                            <fieldset class="mb-xl">
                                <div class="form-group <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-4 control-label" for="old_password">Password Lama</label>
                                    <div class="col-md-8">
                                        <input name="old_password" id="old_password" type="text" class="form-control" placeholder="Password Lama...">
                                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </fieldset>
                            <hr class="dotted short">
                            <fieldset class="mb-xl">
                                <div class="form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <label class="col-md-4 control-label" for="password">Password Baru</label>
                                    <div class="col-md-8">
                                        <input name="password" id="password" type="password" class="form-control" placeholder="Password Baru...">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="has-error" role="alert">
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="password_confirmation">Konfirmasi Password</label>
                                    <div class="col-md-8">
                                        <input name="password_confirmation" id="password_confirmation" type="password" class="form-control" placeholder="Konfirmasi Password...">
                                    </div>
                                </div>
                            </fieldset>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-md-9 col-md-offset-3">
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                        <button type="reset" class="btn btn-default">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    function previewImage(input) {
        var file = $("input[type=file]").get(0).files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function() {
                $('#preview_pengguna').attr("src", reader.result);
            }
            reader.readAsDataURL(file);
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Music\back up\Peminjaman-Sarpras - Copy\resources\views/back/pengguna/edit.blade.php ENDPATH**/ ?>