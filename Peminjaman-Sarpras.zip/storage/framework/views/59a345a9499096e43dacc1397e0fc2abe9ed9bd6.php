<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="header-cart-item flex-w flex-t m-b-12 p-t-12">
    <div class="header-cart-item-img" onClick="mini_draft_destroy(<?php echo e($data->id); ?>)">
        <img src="<?php echo e(url('/storage/'. $data->sarpras->photo)); ?>" alt="IMG">
    </div>

    <div class="header-cart-item-txt" style="margin-top: -5px;">
        <a href="/sarpras_detail/<?php echo e($data->sarpras->id); ?>" class="header-cart-item-name m-b-18 hov-cl1 trans-04">
            <?php echo e($data->sarpras->nama); ?>

        </a>

        <span class="header-cart-item-info" style="margin-top: -15px;">
            <?php echo e($data->qty); ?>

        </span>
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/front/draft/mini_draft.blade.php ENDPATH**/ ?>