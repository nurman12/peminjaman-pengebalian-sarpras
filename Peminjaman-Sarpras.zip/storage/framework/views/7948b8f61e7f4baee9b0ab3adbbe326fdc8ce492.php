<tr class="table_head">
    <th class="p-l-30">Nama Sarpras</th>
    <th></th>
    <th class="txt-center">Quantity</th>
</tr>
<?php $__currentLoopData = $draft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="table_row">
    <td class="text-center p-l-30">
        <div class="how-itemcart1" style="width: 90px;" onclick="draft_destroy(<?php echo e($data->id); ?>)">
            <img src="<?php echo e(url('/storage/sarpras/'. $data->sarpras->photo)); ?>" alt="IMG">
        </div>
    </td>
    <td><?php echo e($data->sarpras->nama); ?></td>
    <td class="action-update" style="padding-left: 80px;">
        <div class="wrap-num-product flex-w quantity txt-center">
            <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
                <i class="fs-16 zmdi zmdi-minus"></i>
            </div>
            <input type="hidden" value="<?php echo e($data->id); ?>" id="draft_id">
            <input type="hidden" value="<?php echo e($data->sarpras->jumlah); ?>" id="max_qty">
            <input class="mtext-104 cl3 txt-center num-product qty-input" type="number" value="<?php echo e($data->qty); ?>">
            <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
                <i class="fs-16 zmdi zmdi-plus"></i>
            </div>
        </div>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- plus minus draft -->
<script src="<?php echo e(asset('/front')); ?>/vendor/jquery/jquery-3.2.1.min.js"></script>
<script>
    $('.btn-num-product-up').click(function(e) {
        e.preventDefault();
        let incre = $(this).parents('.quantity').find('.qty-input').val();
        let max = $(this).parents('.quantity').find('#max_qty').val();
        var draft_id = $(this).parents('.quantity').find('#draft_id').val();
        let value = parseInt(incre);
        if (value < max) {
            value++;
            $(this).parents('.quantity').find('.qty-input').val(value);
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            method: "PUT",
            url: "/draft/" + draft_id,
            data: {
                'qty': value,
            },
            success: function(response) {}
        });
    });

    $('.btn-num-product-down').click(function(e) {
        e.preventDefault();
        let decre = $(this).parents('.quantity').find('.qty-input').val();
        var draft_id = $(this).parents('.quantity').find('#draft_id').val();
        let value = parseInt(decre);
        if (value > 1) {
            value--;
            $(this).parents('.quantity').find('.qty-input').val(value);
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            method: "PUT",
            url: "/draft/" + draft_id,
            data: {
                'qty': value,
            },
            success: function(response) {}
        });
    });
</script>
<!-- end plus minus --><?php /**PATH C:\Users\Nur\Music\back up\Peminjaman-Sarpras - Copy\resources\views/front/draft/table.blade.php ENDPATH**/ ?>