## How to use this app

- Create database
- Run command [php artisan db:seed]()
- Run server [php artisan serve]()
- NIM/NIDN/NIP [962916038]
- Password [12345678]
