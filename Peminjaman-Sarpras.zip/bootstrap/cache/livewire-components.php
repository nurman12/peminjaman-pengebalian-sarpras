<?php return array (
  'messages' => 'App\\Http\\Livewire\\Messages',
);