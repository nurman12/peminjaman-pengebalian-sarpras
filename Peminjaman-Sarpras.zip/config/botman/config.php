<?php
 
return [
    'conversation_cache_time' => 30000,
    'user_cache_time' => 30000,
];
